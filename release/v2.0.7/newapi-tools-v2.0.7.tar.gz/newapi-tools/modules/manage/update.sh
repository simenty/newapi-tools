#!/bin/bash
# 更新 NewAPI v2.0（含备份与自动回滚）
# 新增：状态管理、UI 增强、进度显示、智能回滚
set -euo pipefail

# shellcheck source=lib/common.sh
source "${TOOLKIT_ROOT}/lib/common.sh"
# shellcheck source=lib/state.sh
source "${TOOLKIT_ROOT}/lib/state.sh"
# shellcheck source=lib/ui.sh
source "${TOOLKIT_ROOT}/lib/ui.sh"
# shellcheck source=lib/config.sh
source "${TOOLKIT_ROOT}/lib/config.sh"

check_root
require_docker

# ---------- 设置错误捕获 ----------
trap 'trap_error $LINENO "$BASH_COMMAND"' ERR

cd "$NEWAPI_HOME" || { ui_error "目录不存在: $NEWAPI_HOME"; exit 1; }

# ---------- 显示新手提示 ----------
novice_prompt "更新前会自动备份数据，然后拉取最新 NewAPI 镜像并重启容器。如果健康检查失败，会自动回滚到旧版本。"

# ---------- 更新前状态检查 ----------
if ! is_step_completed "newapi_install"; then
    ui_warn "未检测到 NewAPI 安装，请先执行安装（菜单选项 2）"
    exit 1
fi

# ---------- 步骤 1：更新前自动备份 ----------
ui_info "步骤 1/4：更新前自动备份..."
show_progress 1 4 "更新进度"

ui_info "正在执行自动备份..."
if bash "${TOOLKIT_ROOT}/modules/manage/backup.sh" --cron; then
    ui_success "备份完成"
else
    ui_error "备份失败，更新已取消"
    exit 1
fi

update_install_status "updating" "backup_done"
show_progress 2 4 "更新进度"

# ---------- 步骤 2：记录当前镜像 ID ----------
ui_info "步骤 2/4：记录当前版本信息..."
show_progress 2 4 "更新进度"

OLD_IMAGE_ID=$(docker inspect --format='{{.Image}}' new-api 2>/dev/null || true)
OLD_VERSION=$(docker inspect --format='{{.Config.Image}}' new-api 2>/dev/null || echo "unknown")

if [[ -z "$OLD_IMAGE_ID" ]]; then
    ui_warn "无法获取当前镜像 ID，回滚功能将不可用"
fi

ui_info "当前版本: $OLD_VERSION"
update_install_status "updating" "version_recorded"
show_progress 3 4 "更新进度"

# ---------- 步骤 3：拉取最新镜像 ----------
ui_info "步骤 3/4：拉取最新 NewAPI 镜像..."
show_progress 3 4 "更新进度"

ui_info "正在拉取最新镜像（可能需要几分钟）..."
if ! $DOCKER_COMPOSE_CMD pull new-api; then
    ui_error "镜像拉取失败，更新中断"
    update_install_status "failed" "pull_failed"
    exit 1
fi

ui_success "镜像拉取完成"
update_install_status "updating" "image_pulled"
show_progress 4 4 "更新进度"

# ---------- 步骤 4：重新创建容器 ----------
ui_info "步骤 4/4：重启 NewAPI 容器（应用新镜像）..."
show_progress 4 4 "更新进度"

if ! $DOCKER_COMPOSE_CMD up -d new-api; then
    ui_error "容器重启失败"
    update_install_status "failed" "container_start_failed"
    exit 1
fi

ui_success "容器已重启，等待健康检查..."
update_install_status "updating" "waiting_health_check"

# ---------- 等待健康检查（最多 90 秒）----------
ui_info "等待容器健康检查通过（最多 90 秒）..."
HEALTH_PASSED=false

for i in $(seq 1 30); do
    sleep 3
    show_progress "$i" 30 "健康检查"
    
    CONTAINER_STATUS=$(docker inspect --format='{{.State.Health.Status}}' new-api 2>/dev/null || echo "unhealthy")
    
    if [[ "$CONTAINER_STATUS" == "healthy" ]]; then
        HEALTH_PASSED=true
        echo ""  # 换行
        break
    fi
done

echo ""  # 换行

# ---------- 健康检查失败，执行回滚 ----------
if [[ "$HEALTH_PASSED" == "false" ]]; then
    ui_error "新版本容器健康检查未通过，开始自动回滚..."
    update_install_status "rollback" "start"
    
    if [[ -n "$OLD_IMAGE_ID" ]]; then
        # 回滚到旧镜像
        docker tag "$OLD_IMAGE_ID" calciumion/new-api:latest
        $DOCKER_COMPOSE_CMD up -d new-api
        
        ui_warn "已回滚至更新前版本"
        ui_info "建议：手动排查新版本问题"
        
        update_install_status "completed" "rollback_done"
        
        # 发送 Webhook 告警
        send_webhook "NewAPI 更新回滚" \
            "服务器 $(hostname) 的 NewAPI 自动更新失败，已自动回滚至旧版本 ${OLD_VERSION}。请手动排查新版本问题。"
        
        exit 1
    else
        ui_error "无法回滚：旧镜像 ID 未知，请手动处理！"
        
        send_webhook "NewAPI 更新失败（无法回滚）" \
            "服务器 $(hostname) 的 NewAPI 更新失败且无法回滚，请立即人工介入！"
        
        update_install_status "failed" "rollback_failed"
        exit 1
    fi
fi

# ---------- 清理旧镜像 ----------
ui_info "清理旧镜像..."
$DOCKER_COMPOSE_CMD exec -T new-api true 2>/dev/null  # 确认容器可用
docker image prune -f &>/dev/null || true

# ---------- 更新成功 ----------
update_install_status "completed" "update_done"
mark_step_completed "update_$(date +%Y%m%d_%H%M%S)"

NEW_VERSION=$(docker inspect --format='{{.Config.Image}}' new-api 2>/dev/null || echo "latest")
set_state "newapi.version" "$NEW_VERSION"

# 显示更新摘要
show_summary "更新完成" \
    "✓ 旧版本已备份" \
    "✓ 已更新到最新版本" \
    "✓ 容器健康状态正常" \
    "✓ 旧镜像已清理" \
    "" \
    "更新前版本: $OLD_VERSION" \
    "当前版本:   $NEW_VERSION"

# 发送通知
send_webhook "NewAPI 更新成功" \
    "服务器 $(hostname) 的 NewAPI 已从 ${OLD_VERSION} 更新到 ${NEW_VERSION}"

ui_success "NewAPI 更新成功，容器健康状态正常！"

# 询问是否查看健康状态（新手模式）
if_novice && {
    if ask_yn "是否查看详细健康状态？" "y"; then
        bash "${TOOLKIT_ROOT}/modules/monitor/health.sh"
    fi
}
