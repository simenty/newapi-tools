#!/bin/bash
# 状态管理模块 —— 支持断点续装
# 使用 JSON 文件跟踪系统状态，避免因中断导致重复操作

STATE_FILE="${STATE_FILE:-${TOOLKIT_ROOT}/state.json}"

# ---------- 初始化状态文件 ----------
init_state() {
    if [[ ! -f "$STATE_FILE" ]]; then
        cat > "$STATE_FILE" << 'EOF'
{
  "version": "2.0",
  "last_update": "",
  "installation": {
    "status": "not_started",
    "step": "",
    "completed_steps": [],
    "config": {}
  },
  "system": {
    "docker_installed": false,
    "dns_configured": false,
    "apt_sourced": false
  },
  "newapi": {
    "installed": false,
    "version": "",
    "compose_file": "",
    "env_file": ""
  }
}
EOF
        # 直接更新时间戳，避免递归调用
        if command -v jq &>/dev/null; then
            local tmp_file
            tmp_file=$(mktemp)
            jq ".last_update = \"$(date '+%Y-%m-%d %H:%M:%S')\"" "$STATE_FILE" > "$tmp_file" 2>/dev/null && mv "$tmp_file" "$STATE_FILE"
        fi
        log_info "状态文件已初始化: $STATE_FILE"
    fi
}

# ---------- 读取状态值 ----------
get_state() {
    local key="$1"
    local default="${2:-}"
    
    if [[ ! -f "$STATE_FILE" ]]; then
        echo "$default"
        return 1
    fi
    
    local value=""
    
    # 尝试使用 jq 解析 JSON（支持嵌套键）
    if command -v jq &>/dev/null; then
        value=$(jq -r ".$key // empty" "$STATE_FILE" 2>/dev/null || echo "")
    fi
    
    # 如果 jq 失败，尝试 Python（支持嵌套键和数组）
    if [[ -z "$value" ]] && command -v python3 &>/dev/null; then
        value=$(python3 -c "
import json
try:
    with open('$STATE_FILE', 'r') as f:
        data = json.load(f)
    keys = '$key'.split('.')
    result = data
    for k in keys:
        if isinstance(result, dict):
            result = result.get(k, {})
        elif isinstance(result, list) and k.isdigit():
            result = result[int(k)] if int(k) < len(result) else {}
        else:
            result = {}
    if result and result != {}:
        print(result)
except:
    pass
" 2>/dev/null || echo "")
    fi
    
    # 降级方案：使用 grep 简单解析（只支持一级键）
    if [[ -z "$value" ]] && command -v grep &>/dev/null; then
        value=$(grep "\"$key\"" "$STATE_FILE" | sed 's/.*: *"*\([^,"]*\)"*.*/\1/' | head -1)
    fi
    
    # 如果没找到，返回默认值
    if [[ -z "$value" ]]; then
        echo "$default"
        return 1
    fi
    
    echo "$value"
    return 0
}

# ---------- 更新状态值 ----------
set_state() {
    local key="$1"
    local value="$2"
    
    # 确保状态文件存在
    init_state >/dev/null
    
    local tmp_file
    
    # 尝试使用 jq 安全更新（支持创建新键）
    if command -v jq &>/dev/null; then
        tmp_file=$(mktemp)
        # 使用 --arg 避免命令注入
        if jq --arg key "$key" --arg val "$value" '.[$key] = $val' "$STATE_FILE" > "$tmp_file" 2>/dev/null; then
            mv "$tmp_file" "$STATE_FILE"
            log_debug "状态已更新: $key = $value"
            return 0
        else
            rm -f "$tmp_file"
            log_warn "jq 更新失败，尝试其他方法"
        fi
    fi
    
    # 降级方案：使用 sed 简单替换或追加
    if grep -q "\"$key\"" "$STATE_FILE" 2>/dev/null; then
        # 键存在，替换值
        sed -i "s|\"$key\": *\"[^\"]*\"|\"$key\": \"$value\"|" "$STATE_FILE"
        log_debug "状态已更新（sed）: $key = $value"
        return 0
    else
        # 键不存在，追加到 JSON 对象中
        # 简单处理：在最后一个 } 前插入新键值对
        sed -i "s/}$/,\n  \"$key\": \"$value\"\n}/" "$STATE_FILE" 2>/dev/null
        log_debug "状态已创建（sed）: $key = $value"
        return 0
    fi
}

# ---------- 标记步骤完成 ----------
mark_step_completed() {
    local step="$1"
    
    # 确保状态文件存在
    init_state >/dev/null
    
    local completed_steps
    completed_steps=$(get_state "installation.completed_steps" "[]")
    
    if [[ ! "$completed_steps" =~ "\"$step\"" ]]; then
        if command -v jq &>/dev/null; then
            local tmp_file
            tmp_file=$(mktemp)
            jq ".installation.completed_steps += [\"$step\"]" "$STATE_FILE" > "$tmp_file" 2>/dev/null && mv "$tmp_file" "$STATE_FILE"
        else
            # 降级方案：读取后重写（简单但可靠）
            local steps_json
            steps_json=$(grep "\"completed_steps\"" "$STATE_FILE" | sed 's/.*: *\(\[.*\]\).*/\1/')
            if [[ -z "$steps_json" || "$steps_json" == "[]" ]]; then
                sed -i "s/\"completed_steps\": \[\]/\"completed_steps\": [\"$step\"]/" "$STATE_FILE" 2>/dev/null || true
            else
                # 数组非空，追加（简单处理，可能不完美）
                sed -i "s/\"completed_steps\": \[/\"completed_steps\": [\"$step\",/" "$STATE_FILE" 2>/dev/null || true
            fi
        fi
        log_info "步骤已完成: $step"
    fi
}

# ---------- 检查步骤是否完成 ----------
is_step_completed() {
    local step="$1"
    
    if [[ ! -f "$STATE_FILE" ]]; then
        return 1
    fi
    
    # 尝试使用 jq
    if command -v jq &>/dev/null; then
        local completed_steps
        completed_steps=$(jq -r ".installation.completed_steps[]?" "$STATE_FILE" 2>/dev/null | grep -Fx "$step")
        if [[ -n "$completed_steps" ]]; then
            return 0
        fi
    # 降级方案：直接 grep 状态文件
    elif command -v grep &>/dev/null; then
        if grep -q "\"$step\"" "$STATE_FILE" 2>/dev/null; then
            return 0
        fi
    fi
    
    return 1
}

# ---------- 更新安装状态 ----------
update_install_status() {
    local status="$1"
    local current_step="${2:-}"
    
    set_state "installation.status" "$status"
    
    if [[ -n "$current_step" ]]; then
        set_state "installation.step" "$current_step"
    fi
    
    log_info "安装状态: $status${current_step:+ ($current_step)}"
}

# ---------- 清除状态 ----------
clear_state() {
    rm -f "$STATE_FILE"
    log_info "状态文件已清除"
}

# ---------- 显示状态摘要 ----------
show_state_summary() {
    if [[ ! -f "$STATE_FILE" ]]; then
        echo "状态文件不存在"
        return 1
    fi
    
    echo "========== 系统状态摘要 =========="
    echo "最后更新: $(get_state 'last_update')"
    echo "安装状态: $(get_state 'installation.status')"
    echo "当前步骤: $(get_state 'installation.step')"
    echo "Docker:   $(get_state 'system.docker_installed')"
    echo "NewAPI:   $(get_state 'newapi.installed')"
    echo "=================================="
}

# ---------- 导出函数 ----------
export -f init_state get_state set_state
export -f mark_step_completed is_step_completed
export -f update_install_status clear_state show_state_summary
