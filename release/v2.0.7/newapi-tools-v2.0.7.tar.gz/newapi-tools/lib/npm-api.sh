#!/bin/bash
# NPM API 交互函数

NPM_URL="http://127.0.0.1:81"

npm_login() {
    local email="$1"
    local password="$2"
    local resp
    resp=$(curl -s -X POST -H "Content-Type: application/json" \
        -d "{\"identity\":\"$email\",\"scope\":\"user\",\"secret\":\"$password\"}" \
        "$NPM_URL/api/tokens")
    echo "$resp" | grep -o '"token":"[^"]*' | cut -d'"' -f4
}