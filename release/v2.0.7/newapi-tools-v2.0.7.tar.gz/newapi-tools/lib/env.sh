#!/bin/bash
# NewAPI 运维工具集 — 环境变量与配置加载（资深开发修复版）
# 
# ⚠️ [V2.0 兼容性层 - 计划在 V3.0 移除]
# 此文件提供 v1.0 风格的环境变量配置，用于向后兼容。
# 新代码应使用 lib/config.sh 中的 YAML 配置系统。
#
# 迁移指南：
#   - 使用 get_config("deploy.xxx") 替代 ${DEPLOY_XXX}
#   - 使用 set_config("deploy.xxx" "value") 替代 export DEPLOY_XXX=value
#   - 在 V3.0 中，此文件将被完全移除

# ---------- 配置路径 ----------
CONFIG_FILE="${TOOLKIT_ROOT}/config/toolkit.conf"
PROFILES_DIR="${TOOLKIT_ROOT}/config/profiles"

# ---------- 声明全局默认值（仅在未设置时生效）----------
# 使用 -g 声明全局变量，避免局部变量覆盖
: "${NEWAPI_HOME:=/home/new-api}"
: "${BACKUP_RETENTION_DAYS:=30}"
: "${SSH_PORT:=2222}"
: "${DOCKER_COMPOSE_CMD:=docker compose}"
: "${LOG_DIR:=${TOOLKIT_ROOT}/logs}"
export NEWAPI_HOME BACKUP_RETENTION_DAYS SSH_PORT DOCKER_COMPOSE_CMD LOG_DIR

load_config() {
    # 保存当前环境变量（用户显式 export 的值，最高优先级）
    local env_newapi_home="${NEWAPI_HOME:-}"
    local env_backup_retention="${BACKUP_RETENTION_DAYS:-}"
    local env_docker_compose="${DOCKER_COMPOSE_CMD:-}"
    local env_ssh_port="${SSH_PORT:-}"
    local env_log_dir="${LOG_DIR:-}"

    # 加载全局默认配置
    if [[ -f "$CONFIG_FILE" ]]; then
        # shellcheck source=config/toolkit.conf
        source "$CONFIG_FILE"
        log_info "已加载全局配置: $CONFIG_FILE"
    fi

    # 按 TOOL_ENV 加载环境 Profile（覆盖默认配置）
    local env_profile="${TOOL_ENV:-production}"
    if [[ -f "${PROFILES_DIR}/${env_profile}.conf" ]]; then
        # shellcheck source=config/profiles/production.conf
        source "${PROFILES_DIR}/${env_profile}.conf"
        log_info "已加载环境配置: ${env_profile}.conf"
    fi

    # 恢复用户显式设置的环境变量（最高优先级）
    NEWAPI_HOME="${env_newapi_home:-${NEWAPI_HOME}}"
    BACKUP_RETENTION_DAYS="${env_backup_retention:-${BACKUP_RETENTION_DAYS}}"
    DOCKER_COMPOSE_CMD="${env_docker_compose:-${DOCKER_COMPOSE_CMD}}"
    SSH_PORT="${env_ssh_port:-${SSH_PORT}}"
    LOG_DIR="${env_log_dir:-${LOG_DIR}}"

    # 导出供子脚本使用
    export NEWAPI_HOME BACKUP_RETENTION_DAYS SSH_PORT DOCKER_COMPOSE_CMD LOG_DIR

    # 调试输出（仅在 DEBUG 模式）
    if [[ "${DEBUG:-0}" == "1" ]]; then
        log_info "配置加载完成: NEWAPI_HOME=$NEWAPI_HOME, BACKUP_RETENTION_DAYS=$BACKUP_RETENTION_DAYS"
    fi
}

# 执行加载（脚本被 source 时自动执行）
load_config

# 确保必要目录存在
mkdir -p "${NEWAPI_HOME}/backups" "${LOG_DIR}" 2>/dev/null
